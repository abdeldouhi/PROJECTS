#include<stdio.h>
int  F(int N)
{
    if(N == 0)
        return 1 ;
    return N * F(N-1) ;
}
main()
{
    printf("Saisir N : ") ;
    int N  ;
    scanf("%d" , &N) ;
    printf("F(%d) = %d! = %d" , N , N , F(N)) ;

}
