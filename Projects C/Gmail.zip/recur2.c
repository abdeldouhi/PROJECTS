#include<stdio.h>
int Fibo(int N)
{
    if(N==0)
        return 0 ;
    if(N==1)
        return 1 ;
    return Fibo(N-1) + Fibo(N-2) ;
}
main()
{
    int N ;
    printf("Saisir N :") ;
    scanf("%d" , &N) ;

    printf("Fib(%d) = %d" , N , Fibo(N));

}
