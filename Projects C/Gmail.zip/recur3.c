#include<stdio.h>
int pal(int t[] , int i, int f , int l ){
    if(i== l/2)
        return 1;
    if(t[i] == t[f]){
        pal(t , i+1 , f-1 , l) ;
       return 1;
    }
    return 0 ;

}
main()
{
    int n = 6 ,i , t[n];
    printf("Saisir le tableau  : \n") ;
    for(i=0; i<n; i++){
        printf("t%d = " , i) ;
        scanf("%d" , &t[i]) ;
    }
    int k = pal(t,0,n-1,n) ;
    printf("Est palyndrome ? : %d" , k) ;
}
