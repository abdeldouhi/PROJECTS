#include<stdio.h>
maximum(int t [] , int i , int f){
  if(i == f)
        return t[i] ;
  int max = maximum(t , i+1 , f) ;
  if(t[i] < max )
    return max ;
  return t[i] ;
}
main()
{
    int N  = 6 , t[N] , i ;
    printf("Saisir les %d elements : \n" , N) ;
    for(i=0;i<N;i++)
    {
        printf("t%d = " , i) ;
        scanf("%d" , &t[i]) ;
    }

    printf("max : %d" , maximum(t , 0 , N-1)) ;
}
